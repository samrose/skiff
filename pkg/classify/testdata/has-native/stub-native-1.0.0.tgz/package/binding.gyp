{
  "targets": [{
    "target_name": "stub",
    "sources": ["src/stub.c"]
  }]
}
