#include <node_api.h>
/* stub native module — test fixture only */
NAPI_MODULE_INIT() { return exports; }
