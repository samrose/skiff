# left-pad

String left pad utility. Pure JS.
