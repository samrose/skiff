module.exports = Array.isArray || function (val) {
  return !! val && '[object Array]' == toString.call(val);
};
